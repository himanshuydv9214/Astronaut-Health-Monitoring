# ARES code map - backend, frontend, ML (v0.5.0)

The project keeps its normal folder layout so it still runs. This page says which part is which.

## Backend (Python 3.11-3.13, FastAPI + uvicorn, SQLite) - runs everything locally, offline
| Path | What it does |
|---|---|
| `run_ares.py`, `START_ARES.bat`, `start_ares.sh` | Start ARES (interface opens in the browser) |
| `ares/api/server.py` | REST API + WebSocket, background clock, startup/shutdown, health checks |
| `ares/api/tests_api.py` | Test sessions/trials/results, history, trends, CSV/PDF export |
| `ares/engine.py` | Core engine: crew, sensors, detection, incidents, digital twins |
| `ares/emergency/` | Classifier levels, emergency workflow, reports, four-part guidance |
| `ares/anatomy/` | Findings -> 3D regions (`mapping.py`), organ dossiers (`organs.py`) |
| `ares/assessments/` | Permanent test storage (`store.py`), analysis, exports |
| `ares/clinical/`, `ares/environment/`, `ares/mission/`, `ares/radiation/` | Symptoms & labs, cabin air, mission/comms, radiation dose & NASA DONKI |
| `ares/storage.py`, `ares/persistence.py`, `ares/paths.py`, `ares/startup_status.py` | Audit log, history DB, backup/recovery, data folder |
| `ares/assistant/` | Retrieval-only onboard knowledge assistant |
| `ares/simulation/` | Synthetic crew physiology, ECG, scenarios, mission simulation |
| `knowledge_base/` | Onboard protocols, guidance, inventory (demo, unapproved) |
| `desktop/` | Desktop app: launcher, PyInstaller spec, installer, build scripts, offline tests |
| `ares/web/` | Classic dashboard (plain HTML/JS) |
| `tests/` | Automated tests (`python -m pytest`) |

## Frontend (React 18 + TypeScript + Vite, Three.js / React Three Fiber, Plotly, Tailwind v4)
| Path | What it does |
|---|---|
| `web3d/src/App.tsx`, `main.tsx`, `api.ts`, `ui.tsx`, `info.ts`, `styles.css`, `tailwind.css` | App shell, data access, shared UI, theme |
| `web3d/src/pages/` | Overview, Crew, 3D Hologram, Insights, Emergency, Reaction Test, Test History, Simulation, System |
| `web3d/src/components/Hologram.tsx` | 3D holographic body (custom shader, bloom) |
| `web3d/src/components/OrganPanel.tsx` | Organ dossier popup (sections A-F) |
| `web3d/src/components/ui/glass-fold.tsx` | Animated glass background |
| `ares/web3d_dist/` | Built interface served by the backend (`cd web3d && npm ci && npm run build`) |
| `assets/anatomy/` | BodyParts3D 3D model (GLB) + region map |

## ML / data science (scikit-learn, SHAP, NumPy/Pandas/SciPy)
| Path | What it does |
|---|---|
| `scripts/generate_data.py` | Synthetic multi-day crew training data (`ares/data/generate.py`) |
| `scripts/train_models.py` | Trains the Isolation-Forest anomaly model + 30-min risk forecaster -> `models/` |
| `scripts/evaluate.py` | Held-out evaluation |
| `scripts/real_nasa_models.py`, `scripts/validate_real_data.py`, `ares/realdata/` | Models/validation on real NASA OSDR / RadLab data -> `reports/` |
| `scripts/fetch_data.py` | Downloads PhysioNet / NASA DONKI data |
| `ares/intelligence/` | Feature engineering, model wrappers, SHAP explanations, correlations, NEWS2 |
| `ares/twin/` | Personal baselines, trend, drift detection |
| `ares/behavioral/` | PVT-B scoring, behavioral readiness model |
| `ares/processing/` | ECG processing, signal-quality index |
| `models/` | Trained models + model card |
| `data/osdr`, `data/external` | Real NASA OSDR / RadLab / SRAG / DONKI / PhysioNet sample files |
| `reports/` | Results on real NASA data |

## Run it
    pip install -r requirements.txt
    python run_ares.py            (or START_ARES.bat)  ->  http://127.0.0.1:8000
Retrain: `python scripts/generate_data.py` then `python scripts/train_models.py`.

Credits: 3D anatomy BodyParts3D (DBCLS, CC BY 4.0). Data: NASA OSDR, RadLab, SRAG, DONKI; PhysioNet.
Research prototype - not a medical device, not flight-certified.
